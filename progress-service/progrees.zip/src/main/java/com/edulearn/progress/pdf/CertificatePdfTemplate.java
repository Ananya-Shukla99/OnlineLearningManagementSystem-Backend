package com.edulearn.progress.pdf;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Visual templates for course completion PDF certificates.
 * One variant is chosen at random when a certificate is first issued.
 * All templates render vertical (portrait) A4 pages.
 */
public enum CertificatePdfTemplate {

    /** Red corners, gold seal — original EduLearn style */
    CLASSIC_RED,

    /** Soft sage background with botanical-inspired circles */
    SAGE_BOTANICAL,

    /** Midnight teal canvas, botanical left strip, gold serif body column */
    DARK_TEAL_GOLD,

    /** Cream page with pastel corners and modern sans hierarchy */
    PASTEL_MODERN,

    /** Ornate parchment: pinstripe watermark, triple border, crest, banner, seal, quote */
    FORMAL_IVORY_CLASSIC,

    /** Same luxury botanical-night format; wider strip + double gutter rule */
    CREATIVE_COLOR_MOSAIC,

    /** Formal portrait; sapphire geometric header band (achievement style) */
    ACHIEVEMENT_SAPPHIRE,

    /** Formal portrait; emerald geometric header band (achievement style) */
    ACHIEVEMENT_EMERALD;

    public static CertificatePdfTemplate random() {
        CertificatePdfTemplate[] values = values();
        return values[ThreadLocalRandom.current().nextInt(values.length)];
    }
}
