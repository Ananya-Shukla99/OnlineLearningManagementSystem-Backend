package com.edulearn.progress.pdf;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Renders portrait (vertical) A4 certificate PDFs in multiple visual templates.
 */
@Component
public class CertificatePdfGenerator {

    private static final float PAGE_W = PDRectangle.A4.getWidth();
    private static final float PAGE_H = PDRectangle.A4.getHeight();

    private static final String[] MOTIVATION_QUOTES = {
            "Excellence is not a skill; it is an attitude.",
            "Learning is a treasure that follows its owner everywhere.",
            "Success is the sum of small efforts, repeated day after day.",
            "Education is the passport to the future.",
            "Commitment to growth opens every door.",
            "Your dedication today shapes achievements tomorrow."
    };

    @Value("${certificate.output.path}")
    private String certificateOutputPath;

    public String generate(CertificatePdfTemplate template, Long studentId, Long courseId,
            String verificationCode, String courseName, String studentName) {
        try {
            File certDir = new File(certificateOutputPath);
            if (!certDir.exists()) {
                certDir.mkdirs();
            }

            String fileName = "cert_" + studentId + "_" + courseId + ".pdf";
            String filePath = certificateOutputPath + fileName;

            try (PDDocument document = new PDDocument()) {
                PDPage page = new PDPage(PDRectangle.A4);
                document.addPage(page);

                try (PDPageContentStream content = new PDPageContentStream(document, page)) {
                    switch (template) {
                        case CLASSIC_RED -> drawClassicRed(content, verificationCode, courseName, studentName);
                        case SAGE_BOTANICAL -> drawSageBotanical(content, verificationCode, courseName, studentName);
                        case DARK_TEAL_GOLD -> drawDarkTealGold(content, verificationCode, courseName, studentName);
                        case PASTEL_MODERN -> drawPastelModern(content, verificationCode, courseName, studentName);
                        case FORMAL_IVORY_CLASSIC -> drawFormalIvoryClassic(content, verificationCode, courseName,
                                studentName);
                        case CREATIVE_COLOR_MOSAIC -> drawCreativeColorMosaic(content, verificationCode, courseName,
                                studentName);
                        case ACHIEVEMENT_SAPPHIRE -> drawAchievementSapphire(content, verificationCode, courseName,
                                studentName);
                        case ACHIEVEMENT_EMERALD -> drawAchievementEmerald(content, verificationCode, courseName,
                                studentName);
                    }
                }

                document.save(filePath);
            }

            return filePath;
        } catch (IOException e) {
            throw new RuntimeException("Failed to generate certificate PDF: " + e.getMessage(), e);
        }
    }

    private static void fillCircle(PDPageContentStream c, float cx, float cy, float r) throws IOException {
        final int segments = 48;
        for (int i = 0; i <= segments; i++) {
            double ang = 2 * Math.PI * i / segments;
            float x = cx + r * (float) Math.cos(ang);
            float y = cy + r * (float) Math.sin(ang);
            if (i == 0) {
                c.moveTo(x, y);
            } else {
                c.lineTo(x, y);
            }
        }
        c.fill();
    }

    private static String randomMotivationQuote() {
        return MOTIVATION_QUOTES[ThreadLocalRandom.current().nextInt(MOTIVATION_QUOTES.length)];
    }

    private static List<String> wrapText(String text, PDType1Font font, float fontSize, float maxWidth)
            throws IOException {
        List<String> lines = new ArrayList<>();
        if (text == null || text.isBlank()) {
            return lines;
        }
        String[] words = text.trim().split("\\s+");
        StringBuilder current = new StringBuilder();
        for (String w : words) {
            String trial = current.length() == 0 ? w : current + " " + w;
            float tw = font.getStringWidth(trial) / 1000f * fontSize;
            if (tw > maxWidth && current.length() > 0) {
                lines.add(current.toString());
                current = new StringBuilder(w);
            } else {
                current = new StringBuilder(trial);
            }
        }
        if (current.length() > 0) {
            lines.add(current.toString());
        }
        return lines;
    }

    /** Centered italic motivation quote; starts at top Y and flows downward */
    private static void drawMotivationQuote(PDPageContentStream content, String quote, float marginX, float topY,
            float maxWidth, float fontSize, float lineLeading, float gray) throws IOException {
        content.setNonStrokingColor(gray, gray, gray);
        content.setFont(PDType1Font.TIMES_ITALIC, fontSize);
        List<String> lines = wrapText("\"" + quote + "\"", PDType1Font.TIMES_ITALIC, fontSize, maxWidth);
        float y = topY;
        for (String line : lines) {
            float lw = PDType1Font.TIMES_ITALIC.getStringWidth(line) / 1000f * fontSize;
            content.beginText();
            content.newLineAtOffset(marginX + (maxWidth - lw) / 2f, y);
            content.showText(line);
            content.endText();
            y -= lineLeading;
        }
    }

    private static void drawMotivationQuoteRgb(PDPageContentStream content, String quote, float marginX, float topY,
            float maxWidth, float fontSize, float lineLeading, float r, float g, float b) throws IOException {
        content.setNonStrokingColor(r, g, b);
        content.setFont(PDType1Font.TIMES_ITALIC, fontSize);
        List<String> lines = wrapText("\"" + quote + "\"", PDType1Font.TIMES_ITALIC, fontSize, maxWidth);
        float y = topY;
        for (String line : lines) {
            float lw = PDType1Font.TIMES_ITALIC.getStringWidth(line) / 1000f * fontSize;
            content.beginText();
            content.newLineAtOffset(marginX + (maxWidth - lw) / 2f, y);
            content.showText(line);
            content.endText();
            y -= lineLeading;
        }
    }

    /**
     * Decorative botanical strip for portrait midnight certificates (~left third).
     * Stylized leaves and blooms in teal, gold, cream, and russet tones.
     */
    private static void drawBotanicalLeftStrip(PDPageContentStream c, float bandW) throws IOException {
        c.setNonStrokingColor(0.078f, 0.108f, 0.118f);
        c.addRect(0, 0, bandW, PAGE_H);
        c.fill();

        c.setNonStrokingColor(0.20f, 0.36f, 0.34f);
        fillCircle(c, bandW * 0.18f, PAGE_H * 0.78f, 68);
        c.setNonStrokingColor(0.14f, 0.28f, 0.30f);
        fillCircle(c, bandW * 0.52f, PAGE_H * 0.72f, 72);
        c.setNonStrokingColor(0.26f, 0.42f, 0.40f);
        fillCircle(c, bandW * 0.38f, PAGE_H * 0.88f, 48);

        c.setNonStrokingColor(0.58f, 0.48f, 0.32f);
        fillCircle(c, bandW * 0.35f, PAGE_H * 0.42f, 38);
        c.setNonStrokingColor(0.48f, 0.38f, 0.28f);
        fillCircle(c, bandW * 0.62f, PAGE_H * 0.52f, 28);

        c.setNonStrokingColor(0.74f, 0.64f, 0.46f);
        fillCircle(c, bandW * 0.22f, PAGE_H * 0.55f, 26);
        fillCircle(c, bandW * 0.58f, PAGE_H * 0.35f, 20);
        c.setNonStrokingColor(0.82f, 0.76f, 0.58f);
        fillCircle(c, bandW * 0.45f, PAGE_H * 0.28f, 14);
        fillCircle(c, bandW * 0.30f, PAGE_H * 0.62f, 11);

        c.setNonStrokingColor(0.52f, 0.28f, 0.22f);
        fillCircle(c, bandW * 0.72f, PAGE_H * 0.65f, 8);

        c.setStrokingColor(0.38f, 0.30f, 0.22f);
        c.setLineWidth(1.05f);
        c.moveTo(bandW * 0.72f, PAGE_H * 0.02f);
        c.curveTo(bandW * 0.35f, PAGE_H * 0.28f, bandW * 0.55f, PAGE_H * 0.52f, bandW * 0.42f, PAGE_H * 0.96f);
        c.stroke();
        c.moveTo(bandW * 0.22f, PAGE_H * 0.08f);
        c.curveTo(bandW * 0.48f, PAGE_H * 0.22f, bandW * 0.18f, PAGE_H * 0.48f, bandW * 0.52f, PAGE_H * 0.68f);
        c.stroke();
        c.moveTo(bandW * 0.88f, PAGE_H * 0.18f);
        c.curveTo(bandW * 0.62f, PAGE_H * 0.42f, bandW * 0.78f, PAGE_H * 0.62f, bandW * 0.58f, PAGE_H * 0.92f);
        c.stroke();

        c.setStrokingColor(0.48f, 0.42f, 0.30f);
        c.setLineWidth(0.45f);
        c.moveTo(bandW, 0);
        c.lineTo(bandW, PAGE_H);
        c.stroke();
    }

    /** Shared gold-on-midnight copy block (no date/signature — motivation + verify only). */
    private void drawMidnightGoldTextColumn(PDPageContentStream content, float textLeft, float contentW,
            String verificationCode, String courseName, String studentName) throws IOException {
        float goldR = 0.83f;
        float goldG = 0.69f;
        float goldB = 0.42f;
        float lr = 0.70f;
        float lg = 0.72f;
        float lb = 0.74f;
        float cx = textLeft + contentW / 2f;

        content.setNonStrokingColor(goldR, goldG, goldB);
        content.setFont(PDType1Font.TIMES_BOLD, 40);
        String titleStr = "Certificate";
        float tw = PDType1Font.TIMES_BOLD.getStringWidth(titleStr) / 1000f * 40;
        content.beginText();
        content.newLineAtOffset(cx - tw / 2f, 695);
        content.showText(titleStr);
        content.endText();

        content.setFont(PDType1Font.TIMES_BOLD, 11);
        String sub = "O F   A P P R E C I A T I O N";
        float sw = PDType1Font.TIMES_BOLD.getStringWidth(sub) / 1000f * 11;
        content.beginText();
        content.newLineAtOffset(cx - sw / 2f, 658);
        content.showText(sub);
        content.endText();

        content.setFont(PDType1Font.HELVETICA, 10);
        content.setNonStrokingColor(lr * 0.93f, lg * 0.93f, lb * 0.93f);
        String awarded = "Awarded to";
        float aw = PDType1Font.HELVETICA.getStringWidth(awarded) / 1000f * 10;
        content.beginText();
        content.newLineAtOffset(cx - aw / 2f, 618);
        content.showText(awarded);
        content.endText();

        content.setNonStrokingColor(goldR, goldG, goldB);
        content.setFont(PDType1Font.TIMES_BOLD, 26);
        float nw = PDType1Font.TIMES_BOLD.getStringWidth(studentName) / 1000f * 26;
        content.beginText();
        content.newLineAtOffset(cx - nw / 2f, 578);
        content.showText(studentName);
        content.endText();

        content.setStrokingColor(goldR * 0.5f, goldG * 0.5f, goldB * 0.5f);
        content.setLineWidth(0.55f);
        content.moveTo(cx - Math.min(195, contentW * 0.44f), 562);
        content.lineTo(cx + Math.min(195, contentW * 0.44f), 562);
        content.stroke();

        String para = "in recognition of successful completion of " + trimForWidth(courseName, 52)
                + " and demonstrating excellence through EduLearn.";
        content.setFont(PDType1Font.HELVETICA, 10);
        content.setNonStrokingColor(lr * 0.88f, lg * 0.88f, lb * 0.88f);
        List<String> paraLines = wrapText(para, PDType1Font.HELVETICA, 10, contentW - 8);
        float py = 538;
        for (String line : paraLines) {
            float lw = PDType1Font.HELVETICA.getStringWidth(line) / 1000f * 10;
            content.beginText();
            content.newLineAtOffset(cx - lw / 2f, py);
            content.showText(line);
            content.endText();
            py -= 13;
        }

        py -= 20;
        drawMotivationQuoteRgb(content, randomMotivationQuote(), textLeft, py, contentW, 11f, 14f,
                goldR * 0.82f, goldG * 0.76f, goldB * 0.58f);

        drawVerificationOnlyFooter(content, verificationCode, 0.50f, 0.46f, 0.40f, 56);
    }

    /** Single centered verification line (no duplicate date row — used after motivation on informal templates) */
    private static void drawVerificationOnlyFooter(PDPageContentStream content, String verificationCode,
            float textGrayR, float textGrayG, float textGrayB, float footerY) throws IOException {
        content.setNonStrokingColor(textGrayR, textGrayG, textGrayB);
        content.setFont(PDType1Font.HELVETICA_OBLIQUE, 8);
        String vLine = "Verify at edulearn.com/verify  ·  Code " + verificationCode;
        float vWOffset = PDType1Font.HELVETICA_OBLIQUE.getStringWidth(vLine) / 1000f * 8;
        content.beginText();
        content.newLineAtOffset((PAGE_W - vWOffset) / 2f, footerY);
        content.showText(vLine);
        content.endText();
    }

    /** Formal templates: date label left, signature line + label right */
    private static void drawFormalDateSignatureRow(PDPageContentStream content, float inset, float rowY,
            float innerWidth) throws IOException {
        String dateStr = LocalDate.now().toString();
        content.setNonStrokingColor(0.2f, 0.2f, 0.2f);
        content.setFont(PDType1Font.HELVETICA, 10);
        content.beginText();
        content.newLineAtOffset(inset, rowY + 28);
        content.showText("Date: " + dateStr);
        content.endText();

        float mid = inset + innerWidth * 0.58f;
        content.setStrokingColor(0.35f, 0.35f, 0.35f);
        content.setLineWidth(0.7f);
        content.moveTo(mid, rowY + 12);
        content.lineTo(inset + innerWidth, rowY + 12);
        content.stroke();

        content.setFont(PDType1Font.HELVETICA, 9);
        String sigLab = "Signature";
        float sw = PDType1Font.HELVETICA.getStringWidth(sigLab) / 1000f * 9;
        content.beginText();
        content.newLineAtOffset(mid + (innerWidth * 0.42f - sw) / 2f, rowY);
        content.showText(sigLab);
        content.endText();
    }

    /** Original red / gold decorative certificate — portrait vertical flow */
    private void drawClassicRed(PDPageContentStream content, String verificationCode, String courseName,
            String studentName) throws IOException {
        float pageWidth = PAGE_W;
        float pageHeight = PAGE_H;

        content.setNonStrokingColor(1.0f, 1.0f, 1.0f);
        content.addRect(0, 0, pageWidth, pageHeight);
        content.fill();

        content.setNonStrokingColor(0.6f, 0.0f, 0.05f);
        content.moveTo(0, pageHeight);
        content.lineTo(150, pageHeight);
        content.lineTo(0, pageHeight - 150);
        content.fill();

        content.moveTo(pageWidth, pageHeight);
        content.lineTo(pageWidth - 150, pageHeight);
        content.lineTo(pageWidth, pageHeight - 150);
        content.fill();

        content.moveTo(0, 0);
        content.lineTo(120, 0);
        content.lineTo(0, 120);
        content.fill();

        content.moveTo(pageWidth, 0);
        content.lineTo(pageWidth - 120, 0);
        content.lineTo(pageWidth, 120);
        content.fill();

        content.setNonStrokingColor(0.8f, 0.0f, 0.1f);
        content.moveTo(0, pageHeight - 30);
        content.lineTo(180, pageHeight);
        content.lineTo(210, pageHeight);
        content.lineTo(0, pageHeight - 60);
        content.fill();

        content.moveTo(pageWidth, 30);
        content.lineTo(pageWidth - 180, 0);
        content.lineTo(pageWidth - 210, 0);
        content.lineTo(pageWidth, 60);
        content.fill();

        content.setNonStrokingColor(0.7f, 0.5f, 0.1f);
        float sealX = pageWidth / 2;
        float sealY = 740;
        for (int i = 0; i < 30; i++) {
            double angle = 2 * Math.PI * i / 30;
            float x = (float) (sealX + 35 * Math.cos(angle));
            float y = (float) (sealY + 35 * Math.sin(angle));
            if (i == 0) {
                content.moveTo(x, y);
            } else {
                content.lineTo(x, y);
            }
        }
        content.fill();

        content.setNonStrokingColor(1.0f, 1.0f, 1.0f);
        content.setFont(PDType1Font.HELVETICA_BOLD, 10);
        String sealT1 = "BEST";
        float sealT1w = PDType1Font.HELVETICA_BOLD.getStringWidth(sealT1) / 1000 * 10;
        content.beginText();
        content.newLineAtOffset(sealX - (sealT1w / 2), sealY + 8);
        content.showText(sealT1);
        content.endText();

        String sealT2 = "AWARD";
        float sealT2w = PDType1Font.HELVETICA_BOLD.getStringWidth(sealT2) / 1000 * 9;
        content.setFont(PDType1Font.HELVETICA_BOLD, 9);
        content.beginText();
        content.newLineAtOffset(sealX - (sealT2w / 2), sealY - 8);
        content.showText(sealT2);
        content.endText();

        content.setNonStrokingColor(0.0f, 0.0f, 0.0f);
        String titleStr = "Certificate";
        float titleSize = 64;
        content.setFont(PDType1Font.TIMES_BOLD_ITALIC, titleSize);
        float titleWidthOffset = PDType1Font.TIMES_BOLD_ITALIC.getStringWidth(titleStr) / 1000 * titleSize;
        content.beginText();
        content.newLineAtOffset((pageWidth - titleWidthOffset) / 2, 630);
        content.showText(titleStr);
        content.endText();

        String subHeader = "OF APPRECIATION";
        content.setFont(PDType1Font.HELVETICA, 14);
        content.setNonStrokingColor(0.4f, 0.4f, 0.4f);
        float subW = PDType1Font.HELVETICA.getStringWidth(subHeader) / 1000 * 14;
        content.beginText();
        content.newLineAtOffset((pageWidth - subW) / 2, 605);
        content.showText(subHeader);
        content.endText();

        content.setStrokingColor(0.7f, 0.5f, 0.1f);
        content.setLineWidth(1);
        content.moveTo((pageWidth / 2) - 120, 595);
        content.lineTo((pageWidth / 2) + 120, 595);
        content.stroke();

        String prStr = "PROUDLY PRESENTED TO";
        content.setFont(PDType1Font.HELVETICA_BOLD, 11);
        content.setNonStrokingColor(0.5f, 0.5f, 0.5f);
        float prW = PDType1Font.HELVETICA_BOLD.getStringWidth(prStr) / 1000 * 11;
        content.beginText();
        content.newLineAtOffset((pageWidth - prW) / 2, 540);
        content.showText(prStr);
        content.endText();

        content.setNonStrokingColor(0.0f, 0.0f, 0.0f);
        float nsSize = 52;
        content.setFont(PDType1Font.TIMES_BOLD_ITALIC, nsSize);
        float nameWOffset = PDType1Font.TIMES_BOLD_ITALIC.getStringWidth(studentName) / 1000 * nsSize;
        content.beginText();
        content.newLineAtOffset((pageWidth - nameWOffset) / 2, 470);
        content.showText(studentName);
        content.endText();

        content.setStrokingColor(0.2f, 0.2f, 0.2f);
        content.setLineWidth(0.5f);
        content.moveTo((pageWidth / 2) - 180, 465);
        content.lineTo((pageWidth / 2) + 180, 465);
        content.stroke();

        content.setNonStrokingColor(0.4f, 0.4f, 0.4f);
        content.setFont(PDType1Font.TIMES_ROMAN, 13);
        String descText = "This certificate recognizes the successful completion of the course";
        float descW = PDType1Font.TIMES_ROMAN.getStringWidth(descText) / 1000 * 13;
        content.beginText();
        content.newLineAtOffset((pageWidth - descW) / 2, 420);
        content.showText(descText);
        content.endText();

        content.setNonStrokingColor(0.0f, 0.0f, 0.0f);
        content.setFont(PDType1Font.TIMES_BOLD, 22);
        float courseWOffset = PDType1Font.TIMES_BOLD.getStringWidth(courseName) / 1000 * 22;
        content.beginText();
        content.newLineAtOffset((pageWidth - courseWOffset) / 2, 385);
        content.showText(courseName);
        content.endText();

        content.setNonStrokingColor(0.6f, 0.0f, 0.0f);
        content.setFont(PDType1Font.TIMES_BOLD, 15);
        content.beginText();
        content.newLineAtOffset((pageWidth / 2) - 45, 350);
        content.showText("EduLearn " + LocalDate.now().getYear());
        content.endText();

        float quotePad = 72;
        drawMotivationQuote(content, randomMotivationQuote(), quotePad, 248,
                pageWidth - 2 * quotePad, 11, 14, 0.48f);

        drawVerificationOnlyFooter(content, verificationCode, 0.55f, 0.55f, 0.55f, 72);
    }

    /** Sage greens, organic circles, vertical spacing */
    private void drawSageBotanical(PDPageContentStream content, String verificationCode, String courseName,
            String studentName) throws IOException {
        content.setNonStrokingColor(0.88f, 0.90f, 0.85f);
        content.addRect(0, 0, PAGE_W, PAGE_H);
        content.fill();

        content.setNonStrokingColor(0.55f, 0.62f, 0.48f);
        fillCircle(content, 120, PAGE_H - 100, 95);
        content.setNonStrokingColor(0.42f, 0.52f, 0.40f);
        fillCircle(content, PAGE_W - 80, PAGE_H - 160, 75);
        content.setNonStrokingColor(0.65f, 0.72f, 0.58f);
        fillCircle(content, PAGE_W - 140, 180, 110);
        content.setNonStrokingColor(0.50f, 0.58f, 0.45f);
        fillCircle(content, 100, 220, 85);

        content.setNonStrokingColor(0.95f, 0.82f, 0.35f);
        fillCircle(content, 70, PAGE_H - 60, 12);
        fillCircle(content, PAGE_W - 55, PAGE_H - 45, 10);
        fillCircle(content, PAGE_W / 2 + 80, PAGE_H - 200, 11);

        content.setNonStrokingColor(0.1f, 0.12f, 0.1f);
        String titleStr = "CERTIFICATE";
        float titleSize = 38;
        content.setFont(PDType1Font.TIMES_BOLD, titleSize);
        float tw = PDType1Font.TIMES_BOLD.getStringWidth(titleStr) / 1000 * titleSize;
        content.beginText();
        content.newLineAtOffset((PAGE_W - tw) / 2, 680);
        content.showText(titleStr);
        content.endText();

        String sub = "OF APPRECIATION";
        content.setFont(PDType1Font.TIMES_ROMAN, 13);
        float sw = PDType1Font.TIMES_ROMAN.getStringWidth(sub) / 1000 * 13;
        content.beginText();
        content.newLineAtOffset((PAGE_W - sw) / 2, 652);
        content.showText(sub);
        content.endText();

        content.setFont(PDType1Font.HELVETICA, 9);
        String line1 = "THIS CERTIFICATE IS PROUDLY PRESENTED FOR HONORABLE ACHIEVEMENT TO";
        float l1w = PDType1Font.HELVETICA.getStringWidth(line1) / 1000 * 9;
        content.beginText();
        content.newLineAtOffset((PAGE_W - l1w) / 2, 615);
        content.showText(line1);
        content.endText();

        content.setNonStrokingColor(0.12f, 0.38f, 0.22f);
        float nameSize = 36;
        content.setFont(PDType1Font.TIMES_BOLD_ITALIC, nameSize);
        float nw = PDType1Font.TIMES_BOLD_ITALIC.getStringWidth(studentName) / 1000 * nameSize;
        content.beginText();
        content.newLineAtOffset((PAGE_W - nw) / 2, 560);
        content.showText(studentName);
        content.endText();

        content.setStrokingColor(0.15f, 0.15f, 0.15f);
        content.setLineWidth(0.75f);
        content.moveTo(PAGE_W / 2 - 140, 548);
        content.lineTo(PAGE_W / 2 + 140, 548);
        content.stroke();

        content.setNonStrokingColor(0.25f, 0.25f, 0.25f);
        content.setFont(PDType1Font.TIMES_ROMAN, 12);
        String desc = "This certificate recognizes the successful completion of";
        float dw = PDType1Font.TIMES_ROMAN.getStringWidth(desc) / 1000 * 12;
        content.beginText();
        content.newLineAtOffset((PAGE_W - dw) / 2, 505);
        content.showText(desc);
        content.endText();

        content.setFont(PDType1Font.TIMES_BOLD, 18);
        float cw = PDType1Font.TIMES_BOLD.getStringWidth(courseName) / 1000 * 18;
        content.beginText();
        content.newLineAtOffset((PAGE_W - cw) / 2, 472);
        content.showText(courseName);
        content.endText();

        content.setFont(PDType1Font.TIMES_ROMAN, 11);
        content.setNonStrokingColor(0.35f, 0.35f, 0.35f);
        String edu = "EduLearn — " + LocalDate.now().getYear();
        float ew = PDType1Font.TIMES_ROMAN.getStringWidth(edu) / 1000 * 11;
        content.beginText();
        content.newLineAtOffset((PAGE_W - ew) / 2, 430);
        content.showText(edu);
        content.endText();

        drawMotivationQuote(content, randomMotivationQuote(), 70, 260, PAGE_W - 140, 11, 14, 0.42f);

        drawVerificationOnlyFooter(content, verificationCode, 0.42f, 0.42f, 0.42f, 72);
    }

    /** Midnight teal (#1a2426 family) + botanical strip + gold serif — matches luxury reference layout */
    private void drawDarkTealGold(PDPageContentStream content, String verificationCode, String courseName,
            String studentName) throws IOException {
        float bandW = PAGE_W * 0.34f;
        content.setNonStrokingColor(0.102f, 0.141f, 0.149f);
        content.addRect(0, 0, PAGE_W, PAGE_H);
        content.fill();
        drawBotanicalLeftStrip(content, bandW);
        float textLeft = bandW + 36;
        float contentW = PAGE_W - textLeft - 36;
        drawMidnightGoldTextColumn(content, textLeft, contentW, verificationCode, courseName, studentName);
    }

    /** Cream background, pastel corners, modern sans — portrait */
    private void drawPastelModern(PDPageContentStream content, String verificationCode, String courseName,
            String studentName) throws IOException {
        content.setNonStrokingColor(1.0f, 0.99f, 0.96f);
        content.addRect(0, 0, PAGE_W, PAGE_H);
        content.fill();

        content.setNonStrokingColor(0.98f, 0.73f, 0.82f);
        content.moveTo(0, PAGE_H);
        content.lineTo(140, PAGE_H);
        content.lineTo(0, PAGE_H - 180);
        content.fill();
        content.setNonStrokingColor(0.95f, 0.82f, 0.88f);
        content.moveTo(0, PAGE_H);
        content.lineTo(90, PAGE_H);
        content.lineTo(0, PAGE_H - 120);
        content.fill();

        content.setNonStrokingColor(0.75f, 0.88f, 0.86f);
        content.moveTo(PAGE_W, PAGE_H);
        content.lineTo(PAGE_W - 140, PAGE_H);
        content.lineTo(PAGE_W, PAGE_H - 170);
        content.fill();

        content.setNonStrokingColor(0.85f, 0.93f, 0.90f);
        content.moveTo(0, 0);
        content.lineTo(150, 0);
        content.lineTo(0, 150);
        content.fill();

        content.setNonStrokingColor(1.0f, 0.88f, 0.75f);
        content.moveTo(PAGE_W, 0);
        content.lineTo(PAGE_W - 160, 0);
        content.lineTo(PAGE_W, 160);
        content.fill();

        float peachR = 0.96f;
        float peachG = 0.69f;
        float peachB = 0.55f;
        float grey = 0.35f;

        content.setNonStrokingColor(peachR, peachG, peachB);
        String titleStr = "CERTIFICATE";
        float titleSize = 42;
        content.setFont(PDType1Font.HELVETICA_BOLD, titleSize);
        float tw = PDType1Font.HELVETICA_BOLD.getStringWidth(titleStr) / 1000 * titleSize;
        content.beginText();
        content.newLineAtOffset((PAGE_W - tw) / 2, 695);
        content.showText(titleStr);
        content.endText();

        content.setNonStrokingColor(grey, grey, grey);
        String sub = "OF APPRECIATION";
        content.setFont(PDType1Font.HELVETICA, 11);
        float sw = PDType1Font.HELVETICA.getStringWidth(sub) / 1000 * 11;
        content.beginText();
        content.newLineAtOffset((PAGE_W - sw) / 2, 658);
        content.showText(sub);
        content.endText();

        content.setFont(PDType1Font.HELVETICA_OBLIQUE, 12);
        String present = "This certificate is presented to";
        float pw = PDType1Font.HELVETICA_OBLIQUE.getStringWidth(present) / 1000 * 12;
        content.beginText();
        content.newLineAtOffset((PAGE_W - pw) / 2, 615);
        content.showText(present);
        content.endText();

        content.setNonStrokingColor(0.1f, 0.1f, 0.1f);
        content.setFont(PDType1Font.HELVETICA_BOLD, 26);
        float nw = PDType1Font.HELVETICA_BOLD.getStringWidth(studentName) / 1000 * 26;
        content.beginText();
        content.newLineAtOffset((PAGE_W - nw) / 2, 565);
        content.showText(studentName);
        content.endText();

        content.setStrokingColor(0.75f, 0.75f, 0.75f);
        content.setLineWidth(1);
        content.moveTo(PAGE_W / 2 - 160, 545);
        content.lineTo(PAGE_W / 2 + 160, 545);
        content.stroke();

        content.setFont(PDType1Font.HELVETICA, 11);
        content.setNonStrokingColor(grey, grey, grey);
        String desc = "For completing: " + trimForWidth(courseName, 64);
        float descW = PDType1Font.HELVETICA.getStringWidth(desc) / 1000 * 11;
        content.beginText();
        content.newLineAtOffset((PAGE_W - descW) / 2, 505);
        content.showText(desc);
        content.endText();

        drawMotivationQuote(content, randomMotivationQuote(), 56, 300, PAGE_W - 112, 11, 14, grey);

        drawVerificationOnlyFooter(content, verificationCode, 0.48f, 0.48f, 0.48f, 72);
    }

    private static void fillTriangle(PDPageContentStream c, float x1, float y1, float x2, float y2, float x3, float y3,
            float r, float g, float bl) throws IOException {
        c.setNonStrokingColor(r, g, bl);
        c.moveTo(x1, y1);
        c.lineTo(x2, y2);
        c.lineTo(x3, y3);
        c.closePath();
        c.fill();
    }

    private static void drawDoubleBorder(PDPageContentStream c, float inset, float innerW, float innerH)
            throws IOException {
        c.setStrokingColor(0.22f, 0.2f, 0.18f);
        c.setLineWidth(1.15f);
        c.addRect(inset, inset, innerW, innerH);
        c.stroke();
        c.setLineWidth(0.55f);
        c.addRect(inset + 10, inset + 10, innerW - 20, innerH - 20);
        c.stroke();
    }

    private static void drawTriangleMosaicBand(PDPageContentStream c, float bandBottom, float bandTop,
            float[][] colors) throws IOException {
        float bandH = bandTop - bandBottom;
        int cols = 14;
        int rows = 7;
        float cellW = PAGE_W / cols;
        float cellH = bandH / rows;
        int idx = 0;
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                float x = col * cellW;
                float y = bandBottom + row * cellH;
                float[] rgb = colors[(idx + row + col) % colors.length];
                idx++;
                if ((row + col) % 2 == 0) {
                    fillTriangle(c, x, y, x + cellW, y, x, y + cellH, rgb[0], rgb[1], rgb[2]);
                    fillTriangle(c, x + cellW, y, x + cellW, y + cellH, x, y + cellH, rgb[0] * 0.92f,
                            rgb[1] * 0.92f, rgb[2] * 0.92f);
                } else {
                    fillTriangle(c, x, y + cellH, x + cellW, y + cellH, x + cellW, y, rgb[0], rgb[1], rgb[2]);
                    fillTriangle(c, x, y, x + cellW, y + cellH, x, y + cellH, rgb[0] * 0.88f, rgb[1] * 0.88f,
                            rgb[2] * 0.88f);
                }
            }
        }
    }

    private static void drawDiagonalPinstripeWatermark(PDPageContentStream c) throws IOException {
        c.setStrokingColor(0.93f, 0.905f, 0.855f);
        c.setLineWidth(0.35f);
        for (float d = -PAGE_H; d < PAGE_W + PAGE_H; d += 20f) {
            c.moveTo(d, 0);
            c.lineTo(d + PAGE_H * 1.25f, PAGE_H);
            c.stroke();
        }
    }

    private static void drawIvoryCornerOrnaments(PDPageContentStream c, float m) throws IOException {
        float gr = 0.56f;
        float gg = 0.42f;
        float gb = 0.22f;
        c.setStrokingColor(gr, gg, gb);

        c.setLineWidth(1.35f);
        c.moveTo(m, PAGE_H - m);
        c.lineTo(m + 46, PAGE_H - m);
        c.moveTo(m, PAGE_H - m);
        c.lineTo(m, PAGE_H - m - 46);
        c.stroke();
        c.setLineWidth(0.5f);
        c.moveTo(m + 10, PAGE_H - m - 10);
        c.lineTo(m + 38, PAGE_H - m - 10);
        c.moveTo(m + 10, PAGE_H - m - 10);
        c.lineTo(m + 10, PAGE_H - m - 38);
        c.stroke();

        c.setLineWidth(1.35f);
        c.moveTo(PAGE_W - m, PAGE_H - m);
        c.lineTo(PAGE_W - m - 46, PAGE_H - m);
        c.moveTo(PAGE_W - m, PAGE_H - m);
        c.lineTo(PAGE_W - m, PAGE_H - m - 46);
        c.stroke();
        c.setLineWidth(0.5f);
        c.moveTo(PAGE_W - m - 10, PAGE_H - m - 10);
        c.lineTo(PAGE_W - m - 38, PAGE_H - m - 10);
        c.moveTo(PAGE_W - m - 10, PAGE_H - m - 10);
        c.lineTo(PAGE_W - m - 10, PAGE_H - m - 38);
        c.stroke();

        c.setLineWidth(1.35f);
        c.moveTo(m, m);
        c.lineTo(m + 46, m);
        c.moveTo(m, m);
        c.lineTo(m, m + 46);
        c.stroke();
        c.setLineWidth(0.5f);
        c.moveTo(m + 10, m + 10);
        c.lineTo(m + 38, m + 10);
        c.moveTo(m + 10, m + 10);
        c.lineTo(m + 10, m + 38);
        c.stroke();

        c.setLineWidth(1.35f);
        c.moveTo(PAGE_W - m, m);
        c.lineTo(PAGE_W - m - 46, m);
        c.moveTo(PAGE_W - m, m);
        c.lineTo(PAGE_W - m, m + 46);
        c.stroke();
        c.setLineWidth(0.5f);
        c.moveTo(PAGE_W - m - 10, m + 10);
        c.lineTo(PAGE_W - m - 38, m + 10);
        c.moveTo(PAGE_W - m - 10, m + 10);
        c.lineTo(PAGE_W - m - 10, m + 38);
        c.stroke();

        c.setNonStrokingColor(gr + 0.12f, gg + 0.14f, gb + 0.08f);
        fillCircle(c, m + 52, PAGE_H - m - 52, 4);
        fillCircle(c, PAGE_W - m - 52, PAGE_H - m - 52, 4);
        fillCircle(c, m + 52, m + 52, 4);
        fillCircle(c, PAGE_W - m - 52, m + 52, 4);
    }

    private static void drawIvoryTopCrest(PDPageContentStream c, float cx, float crestBaseY) throws IOException {
        c.setStrokingColor(0.48f, 0.36f, 0.22f);
        c.setLineWidth(0.85f);
        c.moveTo(cx - 58, crestBaseY);
        c.curveTo(cx - 28, crestBaseY + 26, cx + 28, crestBaseY + 26, cx + 58, crestBaseY);
        c.stroke();
        c.setNonStrokingColor(0.7f, 0.52f, 0.28f);
        fillCircle(c, cx, crestBaseY + 6, 5);
        c.setNonStrokingColor(0.55f, 0.4f, 0.22f);
        c.setLineWidth(0.6f);
        c.moveTo(cx - 22, crestBaseY + 12);
        c.lineTo(cx - 8, crestBaseY + 28);
        c.lineTo(cx, crestBaseY + 18);
        c.lineTo(cx + 8, crestBaseY + 28);
        c.lineTo(cx + 22, crestBaseY + 12);
        c.stroke();
    }

    private static void drawFormalBronzeSeal(PDPageContentStream c, float cx, float cy, float outerR)
            throws IOException {
        c.setNonStrokingColor(0.68f, 0.5f, 0.26f);
        fillCircle(c, cx, cy, outerR);
        c.setNonStrokingColor(0.88f, 0.76f, 0.48f);
        fillCircle(c, cx, cy, outerR - 5);
        c.setNonStrokingColor(0.52f, 0.38f, 0.2f);
        fillCircle(c, cx, cy, outerR - 12);

        c.setNonStrokingColor(0.95f, 0.86f, 0.55f);
        c.setFont(PDType1Font.HELVETICA_BOLD, 8);
        String sealWord = "MERIT";
        float sw = PDType1Font.HELVETICA_BOLD.getStringWidth(sealWord) / 1000f * 8;
        c.beginText();
        c.newLineAtOffset(cx - sw / 2, cy - 3);
        c.showText(sealWord);
        c.endText();

        c.setStrokingColor(0.42f, 0.3f, 0.16f);
        c.setLineWidth(0.55f);
        for (int i = 0; i < 24; i++) {
            double ang = 2 * Math.PI * i / 24;
            float x1 = cx + (outerR + 2) * (float) Math.cos(ang);
            float y1 = cy + (outerR + 2) * (float) Math.sin(ang);
            float x2 = cx + (outerR + 10) * (float) Math.cos(ang);
            float y2 = cy + (outerR + 10) * (float) Math.sin(ang);
            c.moveTo(x1, y1);
            c.lineTo(x2, y2);
            c.stroke();
        }
    }

    private static void drawDiamondDivider(PDPageContentStream c, float cx, float midY) throws IOException {
        c.setNonStrokingColor(0.62f, 0.48f, 0.26f);
        float s = 5;
        c.moveTo(cx, midY + s);
        c.lineTo(cx + s, midY);
        c.lineTo(cx, midY - s);
        c.lineTo(cx - s, midY);
        c.closePath();
        c.fill();
    }

    /** Rich parchment formal portrait: watermark, triple frame, crest, banner, seal, quote */
    private void drawFormalIvoryClassic(PDPageContentStream content, String verificationCode, String courseName,
            String studentName) throws IOException {
        float frameOut = 22;
        float frameMid = 30;
        float frameIn = 40;
        float textMargin = 52;
        float textWidth = PAGE_W - 2 * textMargin;

        content.setNonStrokingColor(0.965f, 0.935f, 0.875f);
        content.addRect(0, 0, PAGE_W, PAGE_H);
        content.fill();
        content.setNonStrokingColor(0.99f, 0.975f, 0.92f);
        content.addRect(10, 10, PAGE_W - 20, PAGE_H - 20);
        content.fill();

        drawDiagonalPinstripeWatermark(content);

        content.setStrokingColor(0.26f, 0.2f, 0.12f);
        content.setLineWidth(2.4f);
        content.addRect(frameOut, frameOut, PAGE_W - 2 * frameOut, PAGE_H - 2 * frameOut);
        content.stroke();
        content.setStrokingColor(0.58f, 0.44f, 0.24f);
        content.setLineWidth(1.1f);
        content.addRect(frameMid, frameMid, PAGE_W - 2 * frameMid, PAGE_H - 2 * frameMid);
        content.stroke();
        content.setStrokingColor(0.34f, 0.27f, 0.16f);
        content.setLineWidth(0.45f);
        content.addRect(frameIn, frameIn, PAGE_W - 2 * frameIn, PAGE_H - 2 * frameIn);
        content.stroke();

        drawIvoryCornerOrnaments(content, frameIn);
        float cx = PAGE_W / 2;
        drawIvoryTopCrest(content, cx, PAGE_H - frameIn - 36);

        content.setNonStrokingColor(0.06f, 0.05f, 0.05f);
        content.setFont(PDType1Font.TIMES_BOLD, 40);
        String title = "Certificate";
        float tw = PDType1Font.TIMES_BOLD.getStringWidth(title) / 1000f * 40;
        float titleY = PAGE_H - frameIn - 108;
        content.beginText();
        content.newLineAtOffset(cx - tw / 2, titleY);
        content.showText(title);
        content.endText();

        content.setStrokingColor(0.55f, 0.42f, 0.24f);
        content.setLineWidth(0.65f);
        content.moveTo(cx - 105, titleY - 12);
        content.lineTo(cx - 18, titleY - 12);
        content.stroke();
        drawDiamondDivider(content, cx, titleY - 12);
        content.moveTo(cx + 18, titleY - 12);
        content.lineTo(cx + 105, titleY - 12);
        content.stroke();

        String sub = "O F   A P P R E C I A T I O N";
        content.setFont(PDType1Font.HELVETICA_BOLD, 11);
        float sw = PDType1Font.HELVETICA_BOLD.getStringWidth(sub) / 1000f * 11;
        float bannerTop = titleY - 26;
        float bannerBot = titleY - 50;
        content.setNonStrokingColor(0.79f, 0.62f, 0.34f);
        content.moveTo(cx - sw / 2 - 32, bannerTop);
        content.lineTo(cx + sw / 2 + 32, bannerTop);
        content.lineTo(cx + sw / 2 + 22, bannerBot);
        content.lineTo(cx - sw / 2 - 22, bannerBot);
        content.closePath();
        content.fill();
        content.setNonStrokingColor(0.18f, 0.12f, 0.08f);
        content.beginText();
        content.newLineAtOffset(cx - sw / 2, bannerBot + 9);
        content.showText(sub);
        content.endText();

        content.setFont(PDType1Font.TIMES_ROMAN, 11);
        content.setNonStrokingColor(0.42f, 0.38f, 0.34f);
        String pr = "Proudly presented to";
        float pw = PDType1Font.TIMES_ROMAN.getStringWidth(pr) / 1000f * 11;
        float linePr = bannerBot - 38;
        content.beginText();
        content.newLineAtOffset(cx - pw / 2, linePr);
        content.showText(pr);
        content.endText();

        content.setFont(PDType1Font.TIMES_BOLD_ITALIC, 31);
        content.setNonStrokingColor(0.1f, 0.1f, 0.14f);
        float nw = PDType1Font.TIMES_BOLD_ITALIC.getStringWidth(studentName) / 1000f * 31;
        float nameY = linePr - 42;
        content.beginText();
        content.newLineAtOffset(cx - nw / 2, nameY);
        content.showText(studentName);
        content.endText();

        content.setStrokingColor(0.5f, 0.45f, 0.38f);
        content.setLineWidth(0.65f);
        content.moveTo(cx - 182, nameY - 14);
        content.lineTo(cx + 182, nameY - 14);
        content.stroke();

        content.setFont(PDType1Font.TIMES_ROMAN, 12);
        content.setNonStrokingColor(0.38f, 0.36f, 0.33f);
        String body = "For distinguished completion of " + trimForWidth(courseName, 54);
        List<String> bodyLines = wrapText(body, PDType1Font.TIMES_ROMAN, 12, textWidth - 36);
        float ty = nameY - 44;
        for (String line : bodyLines) {
            float lw = PDType1Font.TIMES_ROMAN.getStringWidth(line) / 1000f * 12;
            content.beginText();
            content.newLineAtOffset(cx - lw / 2, ty);
            content.showText(line);
            content.endText();
            ty -= 17;
        }

        ty -= 8;
        String ivoryQuote = randomMotivationQuote();
        List<String> ivoryQuoteLines = wrapText("\"" + ivoryQuote + "\"", PDType1Font.TIMES_ITALIC, 10.5f, textWidth);
        float quoteBlockHeight = ivoryQuoteLines.size() * 13.5f;
        drawMotivationQuote(content, ivoryQuote, textMargin, ty, textWidth, 10.5f, 13.5f, 0.46f);
        drawFormalBronzeSeal(content, cx - 128, ty - quoteBlockHeight - 46, 32);

        drawFormalDateSignatureRow(content, textMargin, 104, textWidth);

        drawVerificationOnlyFooter(content, verificationCode, 0.42f, 0.42f, 0.42f, 48);
    }

    /**
     * Same midnight botanical luxury format as reference: wider foliage strip, embossed gold rule at gutter,
     * gold serif + cool sans body — no date/signature row.
     */
    private void drawCreativeColorMosaic(PDPageContentStream content, String verificationCode, String courseName,
            String studentName) throws IOException {
        float bandW = PAGE_W * 0.37f;
        content.setNonStrokingColor(0.102f, 0.141f, 0.149f);
        content.addRect(0, 0, PAGE_W, PAGE_H);
        content.fill();
        drawBotanicalLeftStrip(content, bandW);

        content.setStrokingColor(0.62f, 0.50f, 0.32f);
        content.setLineWidth(1.25f);
        content.moveTo(bandW, 0);
        content.lineTo(bandW, PAGE_H);
        content.stroke();
        content.setStrokingColor(0.38f, 0.32f, 0.22f);
        content.setLineWidth(0.35f);
        content.moveTo(bandW + 1.5f, 0);
        content.lineTo(bandW + 1.5f, PAGE_H);
        content.stroke();

        float textLeft = bandW + 38;
        float contentW = PAGE_W - textLeft - 34;
        drawMidnightGoldTextColumn(content, textLeft, contentW, verificationCode, courseName, studentName);
    }

    private void drawAchievementHeaderTemplate(PDPageContentStream content, String verificationCode, String courseName,
            String studentName, float[][] mosaicColors, float accentR, float accentG, float accentB, String titleWord)
            throws IOException {
        float bandBottom = PAGE_H - 168;
        drawTriangleMosaicBand(content, bandBottom, PAGE_H, mosaicColors);

        content.setNonStrokingColor(1f, 1f, 1f);
        content.addRect(0, 0, PAGE_W, bandBottom);
        content.fill();

        float inset = 36;
        float innerW = PAGE_W - 2 * inset;
        float innerH = PAGE_H - 2 * inset;
        drawDoubleBorder(content, inset, innerW, innerH);

        content.setFont(PDType1Font.HELVETICA_OBLIQUE, 8);
        content.setNonStrokingColor(0.95f, 0.95f, 0.98f);
        String logo = "EduLearn";
        content.beginText();
        content.newLineAtOffset(PAGE_W - inset - 120, PAGE_H - 36);
        content.showText(logo);
        content.endText();

        float cx = PAGE_W / 2;
        content.setNonStrokingColor(accentR, accentG, accentB);
        content.setFont(PDType1Font.HELVETICA_BOLD, 34);
        float tw = PDType1Font.HELVETICA_BOLD.getStringWidth(titleWord) / 1000f * 34;
        content.beginText();
        content.newLineAtOffset(cx - tw / 2, bandBottom - 52);
        content.showText(titleWord);
        content.endText();

        content.setNonStrokingColor(0.12f, 0.12f, 0.12f);
        content.setFont(PDType1Font.HELVETICA_BOLD, 13);
        String sub = "of Achievement";
        float sw = PDType1Font.HELVETICA_BOLD.getStringWidth(sub) / 1000f * 13;
        content.beginText();
        content.newLineAtOffset(cx - sw / 2, bandBottom - 78);
        content.showText(sub);
        content.endText();

        content.setFont(PDType1Font.HELVETICA_BOLD, 11);
        String pr = "Proudly presented to:";
        float pw = PDType1Font.HELVETICA_BOLD.getStringWidth(pr) / 1000f * 11;
        content.beginText();
        content.newLineAtOffset(cx - pw / 2, bandBottom - 118);
        content.showText(pr);
        content.endText();

        content.setFont(PDType1Font.TIMES_BOLD_ITALIC, 28);
        content.setNonStrokingColor(accentR * 0.95f, accentG * 0.95f, accentB * 0.95f);
        float nw = PDType1Font.TIMES_BOLD_ITALIC.getStringWidth(studentName) / 1000f * 28;
        content.beginText();
        content.newLineAtOffset(cx - nw / 2, bandBottom - 162);
        content.showText(studentName);
        content.endText();

        content.setFont(PDType1Font.TIMES_ROMAN, 11);
        content.setNonStrokingColor(0.35f, 0.35f, 0.35f);
        String lore = "For excellence and commitment demonstrated throughout "
                + trimForWidth(courseName, 46) + ".";
        List<String> loreLines = wrapText(lore, PDType1Font.TIMES_ROMAN, 11, innerW - 80);
        float ly = bandBottom - 208;
        for (String line : loreLines) {
            float lw = PDType1Font.TIMES_ROMAN.getStringWidth(line) / 1000f * 11;
            content.beginText();
            content.newLineAtOffset(cx - lw / 2, ly);
            content.showText(line);
            content.endText();
            ly -= 15;
        }

        drawFormalDateSignatureRow(content, inset + 52, 128, innerW - 104);

        drawVerificationOnlyFooter(content, verificationCode, 0.42f, 0.42f, 0.42f, 50);
    }

    private void drawAchievementSapphire(PDPageContentStream content, String verificationCode, String courseName,
            String studentName) throws IOException {
        float[][] blues = {
                { 0.18f, 0.28f, 0.52f }, { 0.28f, 0.36f, 0.62f }, { 0.42f, 0.44f, 0.72f }, { 0.22f, 0.2f, 0.48f },
                { 0.35f, 0.32f, 0.58f }
        };
        drawAchievementHeaderTemplate(content, verificationCode, courseName, studentName, blues, 0.18f, 0.32f, 0.62f,
                "CERTIFICATE");
    }

    private void drawAchievementEmerald(PDPageContentStream content, String verificationCode, String courseName,
            String studentName) throws IOException {
        float[][] greens = {
                { 0.22f, 0.48f, 0.32f }, { 0.32f, 0.58f, 0.38f }, { 0.48f, 0.68f, 0.42f }, { 0.18f, 0.4f, 0.28f },
                { 0.38f, 0.52f, 0.35f }
        };
        drawAchievementHeaderTemplate(content, verificationCode, courseName, studentName, greens, 0.28f, 0.58f, 0.34f,
                "CERTIFICATE");
    }

    private static String trimForWidth(String text, int maxChars) {
        if (text == null) {
            return "";
        }
        if (text.length() <= maxChars) {
            return text;
        }
        return text.substring(0, maxChars - 1) + "…";
    }
}
